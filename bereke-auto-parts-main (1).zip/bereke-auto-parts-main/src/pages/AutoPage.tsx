import { useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { autoBrands } from '@/data/brands';
import { autoParts, categories, Part } from '@/data/parts';
import PartCard from '@/components/PartCard';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, SlidersHorizontal } from 'lucide-react';

export default function AutoPage() {
  const [searchParams] = useSearchParams();
  const initialBrand = searchParams.get('brand') || '';

  const [selectedBrand, setSelectedBrand] = useState(initialBrand);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [search, setSearch] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  let filtered = autoParts;
  if (selectedBrand) filtered = filtered.filter(p => p.brandId === selectedBrand);
  if (selectedCategory) filtered = filtered.filter(p => p.category === selectedCategory);
  if (search) filtered = filtered.filter(p => p.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold font-[Montserrat] mb-6">Запчасти для автомобилей</h1>

      {/* Brand chips */}
      <div className="flex flex-wrap gap-2 mb-6">
        <Button
          size="sm"
          variant={selectedBrand === '' ? 'default' : 'outline'}
          onClick={() => setSelectedBrand('')}
        >
          Все марки
        </Button>
        {autoBrands.map(b => (
          <Button
            key={b.id}
            size="sm"
            variant={selectedBrand === b.id ? 'default' : 'outline'}
            onClick={() => setSelectedBrand(b.id)}
          >
            {b.name}
          </Button>
        ))}
      </div>

      {/* Search + filters */}
      <div className="flex gap-2 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Поиск запчастей..." className="pl-9" value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <Button variant="outline" onClick={() => setShowFilters(!showFilters)}>
          <SlidersHorizontal className="w-4 h-4" />
        </Button>
      </div>

      {showFilters && (
        <Card className="mb-6">
          <CardContent className="p-4 flex flex-wrap gap-4">
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Категория" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Все категории</SelectItem>
                {categories.map(c => (
                  <SelectItem key={c} value={c}>{c}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button variant="ghost" onClick={() => { setSelectedCategory(''); setSearch(''); setSelectedBrand(''); }}>
              Сбросить
            </Button>
          </CardContent>
        </Card>
      )}

      <p className="text-sm text-muted-foreground mb-4">Найдено: {filtered.length} запчастей</p>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
        {filtered.map(part => (
          <PartCard key={part.id} part={part} />
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-16 text-muted-foreground">
          <p className="text-lg">Ничего не найдено</p>
          <p className="text-sm">Попробуйте изменить фильтры</p>
        </div>
      )}
    </div>
  );
}
