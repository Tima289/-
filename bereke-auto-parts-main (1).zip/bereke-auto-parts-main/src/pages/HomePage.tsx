import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { autoBrands, motoBrands } from '@/data/brands';
import { categories } from '@/data/parts';
import { Search, Truck, Shield, Clock, Star, Car, Bike, ArrowRight } from 'lucide-react';
import { useState } from 'react';

const advantages = [
  { icon: Shield, title: 'Гарантия качества', desc: 'Только оригинальные и проверенные запчасти' },
  { icon: Truck, title: 'Быстрая доставка', desc: 'Доставим в любую точку города' },
  { icon: Clock, title: 'Работаем ежедневно', desc: 'С 9:00 до 20:00 без выходных' },
  { icon: Star, title: 'Лучшие цены', desc: 'Конкурентные цены на все товары' },
];

export default function HomePage() {
  const [search, setSearch] = useState('');

  const filteredAutoBrands = autoBrands.filter(b => b.name.toLowerCase().includes(search.toLowerCase()));
  const filteredMotoBrands = motoBrands.filter(b => b.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div>
      {/* Hero */}
      <section className="relative bg-primary overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 text-[200px]">🔧</div>
          <div className="absolute bottom-10 right-10 text-[150px]">⚙️</div>
        </div>
        <div className="container mx-auto px-4 py-16 md:py-24 relative">
          <div className="max-w-2xl">
            <h1 className="text-4xl md:text-6xl font-black text-primary-foreground font-[Montserrat] mb-4">
              Автосалон<br />запчастей<br /><span className="text-secondary">Береке</span>
            </h1>
            <p className="text-lg text-primary-foreground/80 mb-8">
              Запчасти для автомобилей и мотоциклов. Более 20 марок, тысячи деталей в наличии.
            </p>
            <div className="flex gap-3">
              <Button asChild size="lg" variant="secondary" className="font-semibold">
                <Link to="/auto"><Car className="w-4 h-4 mr-1" /> Авто</Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="font-semibold bg-primary-foreground/10 text-primary-foreground border-primary-foreground/30 hover:bg-primary-foreground/20">
                <Link to="/moto"><Bike className="w-4 h-4 mr-1" /> Мото</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Search */}
      <section className="container mx-auto px-4 -mt-6 relative z-10">
        <Card className="shadow-xl">
          <CardContent className="p-4 md:p-6">
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Поиск по марке авто или мото..."
                  className="pl-9"
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                />
              </div>
              <Button>Найти</Button>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Categories */}
      <section className="container mx-auto px-4 py-12">
        <h2 className="text-2xl font-bold font-[Montserrat] mb-6">Популярные категории</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {categories.map(cat => (
            <Card key={cat} className="hover:shadow-md transition-shadow cursor-pointer group">
              <CardContent className="p-4 text-center">
                <div className="text-3xl mb-2">
                  {cat === 'Двигатель' ? '🔧' : cat === 'Подвеска' ? '🔩' : cat === 'Тормоза' ? '🛞' : cat === 'Электрика' ? '⚡' : cat === 'Кузов' ? '🚗' : cat === 'Трансмиссия' ? '⚙️' : cat === 'Фильтры' ? '🔬' : '🛢️'}
                </div>
                <span className="text-sm font-medium group-hover:text-primary transition-colors">{cat}</span>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Brands */}
      <section className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold font-[Montserrat]">Марки автомобилей</h2>
          <Button asChild variant="ghost" size="sm">
            <Link to="/auto">Все <ArrowRight className="w-4 h-4 ml-1" /></Link>
          </Button>
        </div>
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-3">
          {filteredAutoBrands.slice(0, 16).map(brand => (
            <Link key={brand.id} to={`/auto?brand=${brand.id}`}>
              <Card className="hover:shadow-md hover:border-primary/30 transition-all cursor-pointer">
                <CardContent className="p-3 text-center">
                  <div className="text-2xl mb-1">{brand.logo}</div>
                  <span className="text-xs font-medium">{brand.name}</span>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      {/* Moto brands */}
      <section className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold font-[Montserrat]">Мотоциклы</h2>
          <Button asChild variant="ghost" size="sm">
            <Link to="/moto">Все <ArrowRight className="w-4 h-4 ml-1" /></Link>
          </Button>
        </div>
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3">
          {filteredMotoBrands.map(brand => (
            <Link key={brand.id} to={`/moto?brand=${brand.id}`}>
              <Card className="hover:shadow-md hover:border-primary/30 transition-all cursor-pointer">
                <CardContent className="p-3 text-center">
                  <div className="text-2xl mb-1">{brand.logo}</div>
                  <span className="text-xs font-medium">{brand.name}</span>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      {/* Advantages */}
      <section className="bg-muted/50 py-12">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold font-[Montserrat] mb-8 text-center">Почему выбирают нас</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {advantages.map(({ icon: Icon, title, desc }) => (
              <Card key={title} className="text-center">
                <CardContent className="p-6">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-3">
                    <Icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-1">{title}</h3>
                  <p className="text-sm text-muted-foreground">{desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
