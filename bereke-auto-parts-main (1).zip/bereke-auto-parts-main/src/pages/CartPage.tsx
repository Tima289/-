import { useCart } from '@/contexts/CartContext';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Trash2, Minus, Plus, ShoppingCart, ArrowRight, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';

export default function CartPage() {
  const { items, removeFromCart, updateQuantity, clearCart, totalPrice } = useCart();
  const { toast } = useToast();
  const [showCheckout, setShowCheckout] = useState(false);
  const [orderForm, setOrderForm] = useState({ name: '', phone: '', address: '' });

  const handleOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!orderForm.name.trim() || !orderForm.phone.trim() || !orderForm.address.trim()) {
      toast({ title: 'Заполните все поля', variant: 'destructive' });
      return;
    }
    toast({ title: 'Заказ оформлен!', description: 'Мы свяжемся с вами для подтверждения.' });
    clearCart();
    setShowCheckout(false);
    setOrderForm({ name: '', phone: '', address: '' });
  };

  if (items.length === 0 && !showCheckout) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <ShoppingCart className="w-16 h-16 mx-auto text-muted-foreground/40 mb-4" />
        <h1 className="text-2xl font-bold font-[Montserrat] mb-2">Корзина пуста</h1>
        <p className="text-muted-foreground mb-6">Добавьте запчасти из каталога</p>
        <div className="flex gap-3 justify-center">
          <Button asChild><Link to="/auto">Каталог авто</Link></Button>
          <Button asChild variant="outline"><Link to="/moto">Каталог мото</Link></Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold font-[Montserrat] mb-6">Корзина</h1>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-3">
          {items.map(({ part, quantity }) => (
            <Card key={part.id}>
              <CardContent className="p-4 flex items-center gap-4">
                <div className="w-16 h-16 rounded-lg bg-muted flex items-center justify-center shrink-0">
                  <img src={part.image} alt={part.name} className="w-10 h-10 opacity-40" />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-medium text-sm truncate">{part.name}</h3>
                  <p className="text-xs text-muted-foreground">{part.description}</p>
                  <p className="font-bold mt-1">{(part.price * quantity).toLocaleString('ru-RU')} ₸</p>
                </div>
                <div className="flex items-center gap-1">
                  <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => updateQuantity(part.id, quantity - 1)}>
                    <Minus className="w-3 h-3" />
                  </Button>
                  <span className="w-8 text-center text-sm font-medium">{quantity}</span>
                  <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => updateQuantity(part.id, quantity + 1)}>
                    <Plus className="w-3 h-3" />
                  </Button>
                </div>
                <Button variant="ghost" size="icon" className="text-destructive" onClick={() => removeFromCart(part.id)}>
                  <Trash2 className="w-4 h-4" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div>
          <Card className="sticky top-20">
            <CardContent className="p-6 space-y-4">
              <h2 className="font-bold text-lg">Итого</h2>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Товаров: {items.reduce((s, i) => s + i.quantity, 0)}</span>
                <span className="font-bold text-xl">{totalPrice.toLocaleString('ru-RU')} ₸</span>
              </div>

              {!showCheckout ? (
                <Button className="w-full" onClick={() => setShowCheckout(true)}>
                  Оформить заказ <ArrowRight className="w-4 h-4 ml-1" />
                </Button>
              ) : (
                <form onSubmit={handleOrder} className="space-y-3">
                  <Input placeholder="Ваше имя" value={orderForm.name} onChange={e => setOrderForm(f => ({ ...f, name: e.target.value }))} maxLength={100} />
                  <Input placeholder="Телефон" value={orderForm.phone} onChange={e => setOrderForm(f => ({ ...f, phone: e.target.value }))} maxLength={20} />
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input placeholder="Адрес доставки" className="pl-9" value={orderForm.address} onChange={e => setOrderForm(f => ({ ...f, address: e.target.value }))} maxLength={255} />
                  </div>
                  <Button type="submit" className="w-full">Подтвердить заказ</Button>
                  <Button type="button" variant="ghost" className="w-full" onClick={() => setShowCheckout(false)}>Назад</Button>
                </form>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
