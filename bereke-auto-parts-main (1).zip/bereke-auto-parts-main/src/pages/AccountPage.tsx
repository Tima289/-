import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { User, LogIn, UserPlus, Package, MapPin } from 'lucide-react';
import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';

export default function AccountPage() {
  const { toast } = useToast();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [loginForm, setLoginForm] = useState({ email: '', password: '' });
  const [registerForm, setRegisterForm] = useState({ name: '', email: '', password: '', confirm: '' });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginForm.email || !loginForm.password) {
      toast({ title: 'Заполните все поля', variant: 'destructive' });
      return;
    }
    setIsLoggedIn(true);
    toast({ title: 'Добро пожаловать!' });
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!registerForm.name || !registerForm.email || !registerForm.password) {
      toast({ title: 'Заполните все поля', variant: 'destructive' });
      return;
    }
    if (registerForm.password !== registerForm.confirm) {
      toast({ title: 'Пароли не совпадают', variant: 'destructive' });
      return;
    }
    setIsLoggedIn(true);
    toast({ title: 'Регистрация успешна!' });
  };

  if (isLoggedIn) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold font-[Montserrat]">Личный кабинет</h1>
          <Button variant="outline" onClick={() => setIsLoggedIn(false)}>Выйти</Button>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <Card>
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-3">
                <User className="w-8 h-8 text-primary" />
              </div>
              <h3 className="font-semibold">Профиль</h3>
              <p className="text-sm text-muted-foreground mt-1">Управление данными аккаунта</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-3">
                <Package className="w-8 h-8 text-primary" />
              </div>
              <h3 className="font-semibold">Заказы</h3>
              <p className="text-sm text-muted-foreground mt-1">У вас пока нет заказов</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-3">
                <MapPin className="w-8 h-8 text-primary" />
              </div>
              <h3 className="font-semibold">Адреса</h3>
              <p className="text-sm text-muted-foreground mt-1">Сохранённые адреса доставки</p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-md">
      <h1 className="text-3xl font-bold font-[Montserrat] mb-8 text-center">Личный кабинет</h1>

      <Card>
        <CardContent className="p-6">
          <Tabs defaultValue="login">
            <TabsList className="w-full mb-6">
              <TabsTrigger value="login" className="flex-1"><LogIn className="w-4 h-4 mr-1" /> Вход</TabsTrigger>
              <TabsTrigger value="register" className="flex-1"><UserPlus className="w-4 h-4 mr-1" /> Регистрация</TabsTrigger>
            </TabsList>

            <TabsContent value="login">
              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-1 block">Email</label>
                  <Input type="email" placeholder="email@example.com" value={loginForm.email} onChange={e => setLoginForm(f => ({ ...f, email: e.target.value }))} maxLength={255} />
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">Пароль</label>
                  <Input type="password" placeholder="••••••••" value={loginForm.password} onChange={e => setLoginForm(f => ({ ...f, password: e.target.value }))} maxLength={128} />
                </div>
                <Button type="submit" className="w-full">Войти</Button>
              </form>
            </TabsContent>

            <TabsContent value="register">
              <form onSubmit={handleRegister} className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-1 block">Имя</label>
                  <Input placeholder="Ваше имя" value={registerForm.name} onChange={e => setRegisterForm(f => ({ ...f, name: e.target.value }))} maxLength={100} />
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">Email</label>
                  <Input type="email" placeholder="email@example.com" value={registerForm.email} onChange={e => setRegisterForm(f => ({ ...f, email: e.target.value }))} maxLength={255} />
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">Пароль</label>
                  <Input type="password" placeholder="••••••••" value={registerForm.password} onChange={e => setRegisterForm(f => ({ ...f, password: e.target.value }))} maxLength={128} />
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">Подтвердите пароль</label>
                  <Input type="password" placeholder="••••••••" value={registerForm.confirm} onChange={e => setRegisterForm(f => ({ ...f, confirm: e.target.value }))} maxLength={128} />
                </div>
                <Button type="submit" className="w-full">Зарегистрироваться</Button>
              </form>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
