export interface Part {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  brandId: string;
  image: string;
  inStock: boolean;
}

export const categories = [
  'Двигатель',
  'Подвеска',
  'Тормоза',
  'Электрика',
  'Кузов',
  'Трансмиссия',
  'Фильтры',
  'Масла и жидкости',
];

function generateParts(brandId: string, type: 'auto' | 'moto'): Part[] {
  const prefix = type === 'auto' ? 'A' : 'M';
  const priceMultiplier = type === 'moto' ? 0.7 : 1;

  return [
    { id: `${prefix}-${brandId}-1`, name: 'Тормозные колодки', description: 'Комплект тормозных колодок передних', price: Math.round(4500 * priceMultiplier), category: 'Тормоза', brandId, image: '/placeholder.svg', inStock: true },
    { id: `${prefix}-${brandId}-2`, name: 'Масляный фильтр', description: 'Фильтр масляный оригинальный', price: Math.round(1200 * priceMultiplier), category: 'Фильтры', brandId, image: '/placeholder.svg', inStock: true },
    { id: `${prefix}-${brandId}-3`, name: 'Амортизатор передний', description: 'Амортизатор передней подвески', price: Math.round(12000 * priceMultiplier), category: 'Подвеска', brandId, image: '/placeholder.svg', inStock: true },
    { id: `${prefix}-${brandId}-4`, name: 'Свечи зажигания', description: 'Комплект свечей зажигания (4 шт)', price: Math.round(3200 * priceMultiplier), category: 'Электрика', brandId, image: '/placeholder.svg', inStock: false },
    { id: `${prefix}-${brandId}-5`, name: 'Ремень ГРМ', description: 'Ремень газораспределительного механизма', price: Math.round(5500 * priceMultiplier), category: 'Двигатель', brandId, image: '/placeholder.svg', inStock: true },
    { id: `${prefix}-${brandId}-6`, name: 'Воздушный фильтр', description: 'Фильтр воздушный', price: Math.round(900 * priceMultiplier), category: 'Фильтры', brandId, image: '/placeholder.svg', inStock: true },
    { id: `${prefix}-${brandId}-7`, name: 'Моторное масло 5W-30', description: 'Синтетическое масло 4л', price: Math.round(7800 * priceMultiplier), category: 'Масла и жидкости', brandId, image: '/placeholder.svg', inStock: true },
    { id: `${prefix}-${brandId}-8`, name: 'Передний бампер', description: 'Бампер передний в сборе', price: Math.round(25000 * priceMultiplier), category: 'Кузов', brandId, image: '/placeholder.svg', inStock: false },
  ];
}

import { autoBrands, motoBrands } from './brands';

export const autoParts: Part[] = autoBrands.flatMap(b => generateParts(b.id, 'auto'));
export const motoParts: Part[] = motoBrands.flatMap(b => generateParts(b.id, 'moto'));
export const allParts: Part[] = [...autoParts, ...motoParts];
