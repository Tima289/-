export interface Brand {
  id: string;
  name: string;
  logo: string;
  type: 'auto' | 'moto';
}

export const autoBrands: Brand[] = [
  { id: 'toyota', name: 'Toyota', logo: '🚗', type: 'auto' },
  { id: 'bmw', name: 'BMW', logo: '🚗', type: 'auto' },
  { id: 'mercedes', name: 'Mercedes-Benz', logo: '🚗', type: 'auto' },
  { id: 'honda-auto', name: 'Honda', logo: '🚗', type: 'auto' },
  { id: 'hyundai', name: 'Hyundai', logo: '🚗', type: 'auto' },
  { id: 'kia', name: 'Kia', logo: '🚗', type: 'auto' },
  { id: 'volkswagen', name: 'Volkswagen', logo: '🚗', type: 'auto' },
  { id: 'audi', name: 'Audi', logo: '🚗', type: 'auto' },
  { id: 'nissan', name: 'Nissan', logo: '🚗', type: 'auto' },
  { id: 'mazda', name: 'Mazda', logo: '🚗', type: 'auto' },
  { id: 'ford', name: 'Ford', logo: '🚗', type: 'auto' },
  { id: 'chevrolet', name: 'Chevrolet', logo: '🚗', type: 'auto' },
  { id: 'mitsubishi', name: 'Mitsubishi', logo: '🚗', type: 'auto' },
  { id: 'subaru', name: 'Subaru', logo: '🚗', type: 'auto' },
  { id: 'lexus', name: 'Lexus', logo: '🚗', type: 'auto' },
  { id: 'porsche', name: 'Porsche', logo: '🚗', type: 'auto' },
  { id: 'opel', name: 'Opel', logo: '🚗', type: 'auto' },
  { id: 'renault', name: 'Renault', logo: '🚗', type: 'auto' },
  { id: 'peugeot', name: 'Peugeot', logo: '🚗', type: 'auto' },
  { id: 'skoda', name: 'Škoda', logo: '🚗', type: 'auto' },
  { id: 'lada', name: 'Lada', logo: '🚗', type: 'auto' },
  { id: 'daewoo', name: 'Daewoo', logo: '🚗', type: 'auto' },
];

export const motoBrands: Brand[] = [
  { id: 'honda-moto', name: 'Honda', logo: '🏍️', type: 'moto' },
  { id: 'yamaha', name: 'Yamaha', logo: '🏍️', type: 'moto' },
  { id: 'kawasaki', name: 'Kawasaki', logo: '🏍️', type: 'moto' },
  { id: 'suzuki', name: 'Suzuki', logo: '🏍️', type: 'moto' },
  { id: 'bmw-motorrad', name: 'BMW Motorrad', logo: '🏍️', type: 'moto' },
  { id: 'ducati', name: 'Ducati', logo: '🏍️', type: 'moto' },
];
