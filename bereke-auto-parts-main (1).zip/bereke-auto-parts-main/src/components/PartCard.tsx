import { Part } from '@/data/parts';
import { useCart } from '@/contexts/CartContext';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ShoppingCart, Check } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default function PartCard({ part }: { part: Part }) {
  const { addToCart, items } = useCart();
  const inCart = items.some(i => i.part.id === part.id);

  return (
    <Card className="group overflow-hidden hover:shadow-lg transition-shadow">
      <div className="aspect-square bg-muted flex items-center justify-center overflow-hidden">
        <img src={part.image} alt={part.name} className="w-2/3 h-2/3 object-contain opacity-40 group-hover:scale-110 transition-transform" />
      </div>
      <CardContent className="p-4 space-y-2">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-semibold text-sm leading-tight">{part.name}</h3>
          <Badge variant={part.inStock ? 'default' : 'secondary'} className="text-[10px] shrink-0">
            {part.inStock ? 'В наличии' : 'Под заказ'}
          </Badge>
        </div>
        <p className="text-xs text-muted-foreground line-clamp-2">{part.description}</p>
        <div className="flex items-center justify-between pt-1">
          <span className="font-bold text-lg">{part.price.toLocaleString('ru-RU')} ₸</span>
          <Button
            size="sm"
            variant={inCart ? 'secondary' : 'default'}
            onClick={() => addToCart(part)}
            disabled={!part.inStock}
          >
            {inCart ? <Check className="w-4 h-4" /> : <ShoppingCart className="w-4 h-4" />}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
