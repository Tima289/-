import { Link, useLocation } from 'react-router-dom';
import { ShoppingCart, User, Menu, X, Car, Bike, Phone, Home } from 'lucide-react';
import { useCart } from '@/contexts/CartContext';
import { useState } from 'react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

const navItems = [
  { to: '/', label: 'Главная', icon: Home },
  { to: '/auto', label: 'Авто', icon: Car },
  { to: '/moto', label: 'Мото', icon: Bike },
  { to: '/contacts', label: 'Контакты', icon: Phone },
  { to: '/account', label: 'Кабинет', icon: User },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const { totalItems } = useCart();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-card/95 backdrop-blur border-b shadow-sm">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-lg font-[Montserrat]">Б</span>
            </div>
            <span className="text-xl font-bold font-[Montserrat] text-foreground hidden sm:block">Береке</span>
          </Link>

          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map(({ to, label, icon: Icon }) => (
              <Link
                key={to}
                to={to}
                className={cn(
                  'flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-colors',
                  location.pathname === to
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                )}
              >
                <Icon className="w-4 h-4" />
                {label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <Link to="/cart" className="relative p-2 rounded-lg hover:bg-muted transition-colors">
              <ShoppingCart className="w-5 h-5" />
              {totalItems > 0 && (
                <span className="absolute -top-0.5 -right-0.5 bg-secondary text-secondary-foreground text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center">
                  {totalItems}
                </span>
              )}
            </Link>
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setMobileOpen(!mobileOpen)}
            >
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile nav */}
        {mobileOpen && (
          <nav className="md:hidden border-t bg-card px-4 py-2 space-y-1">
            {navItems.map(({ to, label, icon: Icon }) => (
              <Link
                key={to}
                to={to}
                onClick={() => setMobileOpen(false)}
                className={cn(
                  'flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors',
                  location.pathname === to
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                )}
              >
                <Icon className="w-4 h-4" />
                {label}
              </Link>
            ))}
          </nav>
        )}
      </header>

      {/* Main */}
      <main className="flex-1">{children}</main>

      {/* Footer */}
      <footer className="bg-card border-t mt-auto">
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h3 className="font-bold font-[Montserrat] text-lg mb-2">Береке</h3>
              <p className="text-sm text-muted-foreground">Автосалон запчастей для автомобилей и мотоциклов. Качество и надёжность.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Контакты</h4>
              <p className="text-sm text-muted-foreground">📞 +7 (777) 123-45-67</p>
              <p className="text-sm text-muted-foreground">✉️ info@bereke.kz</p>
              <p className="text-sm text-muted-foreground">📍 г. Алматы, ул. Абая 1</p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Разделы</h4>
              <div className="flex flex-col gap-1">
                {navItems.map(n => (
                  <Link key={n.to} to={n.to} className="text-sm text-muted-foreground hover:text-foreground transition-colors">{n.label}</Link>
                ))}
              </div>
            </div>
          </div>
          <div className="border-t mt-6 pt-4 text-center text-xs text-muted-foreground">
            © 2026 Береке. Все права защищены.
          </div>
        </div>
      </footer>
    </div>
  );
}
