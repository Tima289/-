import React, { createContext, useContext, useState, useCallback } from 'react';
import { Part } from '@/data/parts';

export interface CartItem {
  part: Part;
  quantity: number;
}

interface CartContextType {
  items: CartItem[];
  addToCart: (part: Part) => void;
  removeFromCart: (partId: string) => void;
  updateQuantity: (partId: string, quantity: number) => void;
  clearCart: () => void;
  totalItems: number;
  totalPrice: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [items, setItems] = useState<CartItem[]>([]);

  const addToCart = useCallback((part: Part) => {
    setItems(prev => {
      const existing = prev.find(i => i.part.id === part.id);
      if (existing) {
        return prev.map(i => i.part.id === part.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { part, quantity: 1 }];
    });
  }, []);

  const removeFromCart = useCallback((partId: string) => {
    setItems(prev => prev.filter(i => i.part.id !== partId));
  }, []);

  const updateQuantity = useCallback((partId: string, quantity: number) => {
    if (quantity <= 0) {
      setItems(prev => prev.filter(i => i.part.id !== partId));
    } else {
      setItems(prev => prev.map(i => i.part.id === partId ? { ...i, quantity } : i));
    }
  }, []);

  const clearCart = useCallback(() => setItems([]), []);

  const totalItems = items.reduce((sum, i) => sum + i.quantity, 0);
  const totalPrice = items.reduce((sum, i) => sum + i.part.price * i.quantity, 0);

  return (
    <CartContext.Provider value={{ items, addToCart, removeFromCart, updateQuantity, clearCart, totalItems, totalPrice }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used within CartProvider');
  return ctx;
};
